import { TEMPLATE_1,TEMPLATE_2,TEMPLATE_3,TEMPLATE_4 } from "../../constant/actiontype";

function T1(){
    return{
        type:TEMPLATE_1,
    }
}

function T2(){
    return{
        type:TEMPLATE_2,
    }
}
function T3(){
    return{
        type:TEMPLATE_3,
    }
}
function T4(){
    return{
        type:TEMPLATE_4,
    }
}
export {T1,T2,T3,T4}