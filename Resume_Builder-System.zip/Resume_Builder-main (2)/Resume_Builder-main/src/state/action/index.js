import updateinfo from "./action";
import { T1,T2,T3,T4} from "./Sel_Template";
export  {updateinfo,T1,T2,T3,T4};